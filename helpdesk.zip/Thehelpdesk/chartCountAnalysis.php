<div class="container pt-5">
        <!-- start of summary section  -->
          <section class="">
            <div class="row gx-lg-5">
              
              <div class="hoverEffect col-lg-3 col-md-6 mb-4 mb-lg-0">
                  <!-- card section -->
                <a href="#" class="
                bg-glass
                d-flex
                 align-items-center
                 p-4
                  shadow-4-strong 
                  rounded-6
                  ripple
                  text-reset
                  "
                  data-ripple-color= "hsl(0 , 0% , 75%)"
                  >
                <div class=" bg-theme p-3 rounded-4" >
                  <i class="fas fa-ticket fa-lg text-white fa-fw"></i>
                </div> 
                <div class="ms-4">
                  <p class="text-muted mb-2">
                   <span> Opened Complaints</span>
                  </p>
                  <p class="mb-0">
                    <span class="h5 me-2 opened"></span>
                     <small class="text-danger text-sm percentage">
                      </small>
                  </p>
                </div> 
                </a>
               <!-- card section -->

              </div><!-- col-lg-3 col-md-6 mb-4 mb-lg-0 -->

              <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                    <!-- card section -->
                <a href="#" class="
                bg-glass 
                d-flex
                 align-items-center
                 p-4
                  shadow-4-strong 
                  rounded-6
                  ripple 
                  text-reset
                  "
                  data-ripple-color = "hsl(0 , 0% , 75%)"
                  >
                <div class="bg-theme p-3 rounded-4" >
                  <i class="fas fa-ticket fa-lg text-white fa-fw"></i>
                </div> 
                <div class="ms-4">
                  <p class="text-muted mb-2">
                    Closed Complaints
                  </p>
                  <p class="mb-0">
                    <span class="h5 me-2 closed"></span>
                     <small class="text-success text-sm percentage1">
                       
                      </small>
                  </p>
                </div> 
                </a>
               <!-- card section -->

              </div><!-- col-lg-3 col-md-6 mb-4 mb-lg-0 -->

              <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                  <!-- card section -->
                <a href="#" class="
                bg-glass 
                d-flex
                 align-items-center
                 p-4
                  shadow-4-strong 
                  rounded-6
                  ripple 
                  text-reset
                  "
                  data-ripple-color = "hsl(0 , 0% , 75%)"
                  >
                <div class="bg-theme p-3 rounded-4" >
                  <i class="fas fa-clock fa-lg text-white fa-fw"></i> 
                </div> 
                <div class="ms-4">
                  <p class="text-muted mb-2">
                   Average Time
                  </p>
                  <p class="mb-0">
                    <span class="h5 me-2"> 02:00:00</span>
                     <small class="text-danger text-sm">
                      
                      </small>
                  </p>
                </div> 
                </a>
               <!-- card section -->

              </div><!-- col-lg-3 col-md-6 mb-4 mb-lg-0 -->

              <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                  <!-- card section -->
                <a href="#" class="
                bg-glass 
                d-flex
                 align-items-center
                 p-4
                  shadow-4-strong 
                  rounded-6
                  ripple 
                  text-reset
                  "
                  data-ripple-color = "hsl(0 , 0% , 75%)"
                  >
                <div class="bg-theme p-3 rounded-4" >
                  <i class="fas fa-sign-out-alt fa-lg text-white fa-fw"></i>
                </div> 
                <div class="ms-4">
                  <p class="text-muted mb-2">
                    Coming Soon! 
                  </p>
                  <p class="mb-0">
                    <span class="h5 me-2"></span>
                     <small class="text-success text-sm">
                       <!-- <i class="fas fa-arrow-up fa-sm me-1"></i>43,12% -->
                      </small>
                  </p>
                </div> 
                </a>
               <!-- card section -->

              </div><!-- col-lg-3 col-md-6 mb-4 mb-lg-0 -->

            </div><!-- row -->
          </section><!-- end of summary section -->
